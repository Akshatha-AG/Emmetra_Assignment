import cv2
import numpy as np
#from tensorflow.keras.models import load_model

def load_raw_image(file_path):
    raw_image = np.fromfile(file_path, dtype=np.uint16).reshape((1280, 1920)) 
    raw_image = (raw_image / 16).astype(np.uint8)
    return raw_image

def median_denoise(image, kernel_size=5):
    return cv2.medianBlur(image, kernel_size)

def bilateral_denoise(image, d=9, sigma_color=75, sigma_space=75):
    return cv2.bilateralFilter(image, d, sigma_color, sigma_space)

def gaussian_denoise(image, kernel_size=5):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)

# AI-based Denoising using a pre-trained model (e.g., U-Net)
def ai_denoise(image, model_path='path/to/pretrained_model.h5'):
    model = load_model(model_path)
    image = np.expand_dims(image, axis=(0, -1)) / 255.0 
    denoised_image = model.predict(image)[0] * 255
    denoised_image = denoised_image.clip(0, 255).astype(np.uint8).squeeze()
    return denoised_image

def laplacian_enhancement(image):
    laplacian = cv2.Laplacian(image, cv2.CV_64F)
    enhanced_image = cv2.convertScaleAbs(image - laplacian)
    return enhanced_image

def unsharp_mask(image):
    blurred = cv2.GaussianBlur(image, (5, 5), 1.5)
    sharpened_image = cv2.addWeighted(image, 1.5, blurred, -0.5, 0)
    return sharpened_image

raw_image = load_raw_image("C:/Users/moni2/Desktop/emmetra/Assignment2_input1.raw")

median_denoised = median_denoise(raw_image)
bilateral_denoised = bilateral_denoise(raw_image)
gaussian_denoised = gaussian_denoise(raw_image)

# Apply AI-based Denoising (if model is available)
# ai_denoised = ai_denoise(raw_image, model_path="path/to/your/pretrained_model.h5")

laplacian_enhanced = laplacian_enhancement(raw_image)
unsharp_enhanced = unsharp_mask(raw_image)

cv2.imwrite('median_denoised.png', median_denoised)
cv2.imwrite('bilateral_denoised.png', bilateral_denoised)
cv2.imwrite('gaussian_denoised.png', gaussian_denoised)
#cv2.imwrite('ai_denoised.png', ai_denoised)  # Uncomment if AI model is used

cv2.imwrite('laplacian_enhanced.png', laplacian_enhanced)
cv2.imwrite('unsharp_enhanced.png', unsharp_enhanced)
